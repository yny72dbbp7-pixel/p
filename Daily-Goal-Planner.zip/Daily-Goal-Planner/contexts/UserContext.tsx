import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface UserProfile {
  name: string;
  avatar: string | null;
}

interface UserContextValue {
  user: UserProfile | null;
  isLoading: boolean;
  register: (name: string) => Promise<void>;
  updateName: (name: string) => Promise<void>;
  updateAvatar: (uri: string | null) => Promise<void>;
}

const UserContext = createContext<UserContextValue | null>(null);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem('user_profile').then((val) => {
      if (val) {
        setUser(JSON.parse(val));
      }
      setIsLoading(false);
    });
  }, []);

  const saveUser = async (profile: UserProfile) => {
    setUser(profile);
    await AsyncStorage.setItem('user_profile', JSON.stringify(profile));
  };

  const register = async (name: string) => {
    await saveUser({ name, avatar: null });
  };

  const updateName = async (name: string) => {
    if (user) await saveUser({ ...user, name });
  };

  const updateAvatar = async (uri: string | null) => {
    if (user) await saveUser({ ...user, avatar: uri });
  };

  const value = useMemo(() => ({
    user,
    isLoading,
    register,
    updateName,
    updateAvatar,
  }), [user, isLoading]);

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const ctx = useContext(UserContext);
  if (!ctx) throw new Error('useUser must be used within UserProvider');
  return ctx;
}
