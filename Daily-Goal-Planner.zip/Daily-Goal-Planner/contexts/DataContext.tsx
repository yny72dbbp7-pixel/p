import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';

export interface Habit {
  id: string;
  title: string;
  days: number[];
  isDaily: boolean;
  completedDates: string[];
  createdAt: string;
}

export interface Task {
  id: string;
  title: string;
  note: string;
  deadline: string;
  completed: boolean;
  createdAt: string;
}

export interface Attachment {
  id: string;
  name: string;
  uri: string;
  type: 'image' | 'video' | 'file';
  mimeType?: string;
}

export interface DayPlanItem {
  id: string;
  title: string;
  completed: boolean;
  date: string;
  attachments: Attachment[];
  createdAt: string;
}

export interface DayNote {
  id: string;
  content: string;
  date: string;
  updatedAt: string;
}

export interface FinanceEntry {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  category: string;
  note: string;
  date: string;
  createdAt: string;
}

interface DataContextValue {
  habits: Habit[];
  tasks: Task[];
  dayPlanItems: DayPlanItem[];
  dayNotes: DayNote[];
  finances: FinanceEntry[];
  addHabit: (h: Omit<Habit, 'id' | 'completedDates' | 'createdAt'>) => Promise<void>;
  toggleHabitCompletion: (id: string, date: string) => Promise<void>;
  deleteHabit: (id: string) => Promise<void>;
  addTask: (t: Omit<Task, 'id' | 'completed' | 'createdAt'>) => Promise<void>;
  toggleTask: (id: string) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  addDayPlanItem: (title: string, date: string) => Promise<void>;
  toggleDayPlanItem: (id: string) => Promise<void>;
  deleteDayPlanItem: (id: string) => Promise<void>;
  addAttachment: (itemId: string, attachment: Omit<Attachment, 'id'>) => Promise<void>;
  removeAttachment: (itemId: string, attachmentId: string) => Promise<void>;
  updateDayNote: (date: string, content: string) => Promise<void>;
  getDayNote: (date: string) => DayNote | undefined;
  addFinance: (f: Omit<FinanceEntry, 'id' | 'createdAt'>) => Promise<void>;
  deleteFinance: (id: string) => Promise<void>;
  getHabitStreak: (habit: Habit) => number;
  getTodayStats: () => { habitsTotal: number; habitsDone: number; tasksTotal: number; tasksDone: number; plansTotal: number; plansDone: number; todayExpenses: number };
}

const DataContext = createContext<DataContextValue | null>(null);

const KEYS = {
  habits: 'data_habits',
  tasks: 'data_tasks',
  dayPlan: 'data_dayplan',
  dayNotes: 'data_daynotes',
  finances: 'data_finances',
};

function getToday() {
  return new Date().toISOString().split('T')[0];
}

function getDayOfWeek() {
  return new Date().getDay();
}

export function DataProvider({ children }: { children: ReactNode }) {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [dayPlanItems, setDayPlanItems] = useState<DayPlanItem[]>([]);
  const [dayNotes, setDayNotes] = useState<DayNote[]>([]);
  const [finances, setFinances] = useState<FinanceEntry[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    Promise.all([
      AsyncStorage.getItem(KEYS.habits),
      AsyncStorage.getItem(KEYS.tasks),
      AsyncStorage.getItem(KEYS.dayPlan),
      AsyncStorage.getItem(KEYS.dayNotes),
      AsyncStorage.getItem(KEYS.finances),
    ]).then(([h, t, dp, dn, f]) => {
      if (h) setHabits(JSON.parse(h));
      if (t) setTasks(JSON.parse(t));
      if (dp) setDayPlanItems(JSON.parse(dp));
      if (dn) setDayNotes(JSON.parse(dn));
      if (f) setFinances(JSON.parse(f));
      setLoaded(true);
    });
  }, []);

  const saveHabits = async (data: Habit[]) => {
    setHabits(data);
    await AsyncStorage.setItem(KEYS.habits, JSON.stringify(data));
  };
  const saveTasks = async (data: Task[]) => {
    setTasks(data);
    await AsyncStorage.setItem(KEYS.tasks, JSON.stringify(data));
  };
  const saveDayPlan = async (data: DayPlanItem[]) => {
    setDayPlanItems(data);
    await AsyncStorage.setItem(KEYS.dayPlan, JSON.stringify(data));
  };
  const saveDayNotes = async (data: DayNote[]) => {
    setDayNotes(data);
    await AsyncStorage.setItem(KEYS.dayNotes, JSON.stringify(data));
  };
  const saveFinances = async (data: FinanceEntry[]) => {
    setFinances(data);
    await AsyncStorage.setItem(KEYS.finances, JSON.stringify(data));
  };

  const addHabit = useCallback(async (h: Omit<Habit, 'id' | 'completedDates' | 'createdAt'>) => {
    const newHabit: Habit = { ...h, id: Crypto.randomUUID(), completedDates: [], createdAt: new Date().toISOString() };
    const updated = [...habits, newHabit];
    await saveHabits(updated);
  }, [habits]);

  const toggleHabitCompletion = useCallback(async (id: string, date: string) => {
    const updated = habits.map(h => {
      if (h.id !== id) return h;
      const exists = h.completedDates.includes(date);
      return { ...h, completedDates: exists ? h.completedDates.filter(d => d !== date) : [...h.completedDates, date] };
    });
    await saveHabits(updated);
  }, [habits]);

  const deleteHabit = useCallback(async (id: string) => {
    await saveHabits(habits.filter(h => h.id !== id));
  }, [habits]);

  const addTask = useCallback(async (t: Omit<Task, 'id' | 'completed' | 'createdAt'>) => {
    const newTask: Task = { ...t, id: Crypto.randomUUID(), completed: false, createdAt: new Date().toISOString() };
    await saveTasks([...tasks, newTask]);
  }, [tasks]);

  const toggleTask = useCallback(async (id: string) => {
    await saveTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  }, [tasks]);

  const deleteTask = useCallback(async (id: string) => {
    await saveTasks(tasks.filter(t => t.id !== id));
  }, [tasks]);

  const addDayPlanItem = useCallback(async (title: string, date: string) => {
    const item: DayPlanItem = { id: Crypto.randomUUID(), title, completed: false, date, attachments: [], createdAt: new Date().toISOString() };
    await saveDayPlan([...dayPlanItems, item]);
  }, [dayPlanItems]);

  const toggleDayPlanItem = useCallback(async (id: string) => {
    await saveDayPlan(dayPlanItems.map(i => i.id === id ? { ...i, completed: !i.completed } : i));
  }, [dayPlanItems]);

  const deleteDayPlanItem = useCallback(async (id: string) => {
    await saveDayPlan(dayPlanItems.filter(i => i.id !== id));
  }, [dayPlanItems]);

  const addAttachment = useCallback(async (itemId: string, attachment: Omit<Attachment, 'id'>) => {
    const full: Attachment = { ...attachment, id: Crypto.randomUUID() };
    await saveDayPlan(dayPlanItems.map(i => i.id === itemId ? { ...i, attachments: [...(i.attachments || []), full] } : i));
  }, [dayPlanItems]);

  const removeAttachment = useCallback(async (itemId: string, attachmentId: string) => {
    await saveDayPlan(dayPlanItems.map(i => i.id === itemId ? { ...i, attachments: (i.attachments || []).filter(a => a.id !== attachmentId) } : i));
  }, [dayPlanItems]);

  const updateDayNote = useCallback(async (date: string, content: string) => {
    const existing = dayNotes.find(n => n.date === date);
    let updated: DayNote[];
    if (existing) {
      updated = dayNotes.map(n => n.date === date ? { ...n, content, updatedAt: new Date().toISOString() } : n);
    } else {
      updated = [...dayNotes, { id: Crypto.randomUUID(), content, date, updatedAt: new Date().toISOString() }];
    }
    await saveDayNotes(updated);
  }, [dayNotes]);

  const getDayNote = useCallback((date: string) => {
    return dayNotes.find(n => n.date === date);
  }, [dayNotes]);

  const addFinance = useCallback(async (f: Omit<FinanceEntry, 'id' | 'createdAt'>) => {
    const entry: FinanceEntry = { ...f, id: Crypto.randomUUID(), createdAt: new Date().toISOString() };
    await saveFinances([...finances, entry]);
  }, [finances]);

  const deleteFinance = useCallback(async (id: string) => {
    await saveFinances(finances.filter(f => f.id !== id));
  }, [finances]);

  const getHabitStreak = useCallback((habit: Habit) => {
    const today = new Date();
    let streak = 0;
    for (let i = 0; i < 365; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayOfWeek = d.getDay();
      const isScheduled = habit.isDaily || habit.days.includes(dayOfWeek);
      if (!isScheduled) continue;
      if (habit.completedDates.includes(dateStr)) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  }, []);

  const getTodayStats = useCallback(() => {
    const today = getToday();
    const dow = getDayOfWeek();
    const todayHabits = habits.filter(h => h.isDaily || h.days.includes(dow));
    const habitsDone = todayHabits.filter(h => h.completedDates.includes(today)).length;
    const activeTasks = tasks.filter(t => !t.completed);
    const tasksDone = tasks.filter(t => t.completed).length;
    const todayPlans = dayPlanItems.filter(i => i.date === today);
    const plansDone = todayPlans.filter(i => i.completed).length;
    const todayExpenses = finances
      .filter(f => f.date === today && f.type === 'expense')
      .reduce((sum, f) => sum + f.amount, 0);
    return {
      habitsTotal: todayHabits.length,
      habitsDone,
      tasksTotal: activeTasks.length,
      tasksDone,
      plansTotal: todayPlans.length,
      plansDone,
      todayExpenses,
    };
  }, [habits, tasks, dayPlanItems, finances]);

  const value = useMemo(() => ({
    habits, tasks, dayPlanItems, dayNotes, finances,
    addHabit, toggleHabitCompletion, deleteHabit,
    addTask, toggleTask, deleteTask,
    addDayPlanItem, toggleDayPlanItem, deleteDayPlanItem, addAttachment, removeAttachment,
    updateDayNote, getDayNote,
    addFinance, deleteFinance,
    getHabitStreak, getTodayStats,
  }), [habits, tasks, dayPlanItems, dayNotes, finances, addHabit, toggleHabitCompletion, deleteHabit, addTask, toggleTask, deleteTask, addDayPlanItem, toggleDayPlanItem, deleteDayPlanItem, addAttachment, removeAttachment, updateDayNote, getDayNote, addFinance, deleteFinance, getHabitStreak, getTodayStats]);

  if (!loaded) return null;

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
