import React from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import { useUser } from '@/contexts/UserContext';
import { useData } from '@/contexts/DataContext';

const DAYS_RU = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
const MONTHS_RU = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const WEEKDAYS_RU = ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'];

function StatCard({ icon, iconColor, label, value, total, colors, delay }: any) {
  return (
    <Animated.View entering={FadeInDown.duration(400).delay(delay)} style={[styles.statCard, { backgroundColor: colors.card }]}>
      <View style={[styles.statIconCircle, { backgroundColor: iconColor + '18' }]}>
        <Ionicons name={icon} size={22} color={iconColor} />
      </View>
      <Text style={[styles.statValue, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>
        {total !== undefined ? `${value}/${total}` : value}
      </Text>
      <Text style={[styles.statLabel, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>{label}</Text>
    </Animated.View>
  );
}

export default function OverviewScreen() {
  const { colors } = useTheme();
  const { user } = useUser();
  const { getTodayStats } = useData();
  const insets = useSafeAreaInsets();
  const stats = getTodayStats();
  const now = new Date();
  const weekday = WEEKDAYS_RU[now.getDay()];
  const month = MONTHS_RU[now.getMonth()];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16), paddingBottom: 100 + (Platform.OS === 'web' ? 34 : 0) }]}
        showsVerticalScrollIndicator={false}
        contentInsetAdjustmentBehavior="automatic"
      >
        <View style={styles.headerRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.greeting, { color: colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>
              Привет, {user?.name}
            </Text>
            <Text style={[styles.dateText, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>
              {weekday}, {now.getDate()} {month}
            </Text>
          </View>
          <Pressable
            onPress={() => router.push('/(tabs)/settings')}
            style={({ pressed }) => [styles.settingsBtn, { backgroundColor: colors.card, opacity: pressed ? 0.7 : 1 }]}
          >
            <Ionicons name="settings-outline" size={22} color={colors.text} />
          </Pressable>
        </View>

        <View style={styles.statsGrid}>
          <StatCard icon="flame" iconColor={colors.streak} label="Привычки" value={stats.habitsDone} total={stats.habitsTotal} colors={colors} delay={100} />
          <StatCard icon="checkmark-done" iconColor={colors.primary} label="Задачи" value={stats.tasksDone} total={stats.tasksTotal + stats.tasksDone} colors={colors} delay={200} />
          <StatCard icon="calendar" iconColor="#8B5CF6" label="План дня" value={stats.plansDone} total={stats.plansTotal} colors={colors} delay={300} />
          <StatCard icon="trending-down" iconColor={colors.expense} label="Расходы" value={`${stats.todayExpenses.toLocaleString()}`} colors={colors} delay={400} />
        </View>

        <Animated.View entering={FadeInDown.duration(400).delay(500)}>
          <View style={[styles.summaryCard, { backgroundColor: colors.card }]}>
            <View style={styles.summaryRow}>
              <Ionicons name="pulse" size={20} color={colors.primary} />
              <Text style={[styles.summaryTitle, { color: colors.text, fontFamily: 'Inter_600SemiBold' }]}>Прогресс за день</Text>
            </View>
            <View style={[styles.progressBarBg, { backgroundColor: colors.inputBg }]}>
              <View style={[styles.progressBarFill, { backgroundColor: colors.primary, width: getProgressWidth(stats) }]} />
            </View>
            <Text style={[styles.progressText, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>
              {getProgressPercent(stats)}% выполнено
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

function getProgressWidth(stats: any) {
  const total = stats.habitsTotal + stats.tasksTotal + stats.tasksDone + stats.plansTotal;
  const done = stats.habitsDone + stats.tasksDone + stats.plansDone;
  if (total === 0) return '0%';
  return `${Math.round((done / total) * 100)}%`;
}

function getProgressPercent(stats: any) {
  const total = stats.habitsTotal + stats.tasksTotal + stats.tasksDone + stats.plansTotal;
  const done = stats.habitsDone + stats.tasksDone + stats.plansDone;
  if (total === 0) return 0;
  return Math.round((done / total) * 100);
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingHorizontal: 20 },
  headerRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 28 },
  greeting: { fontSize: 15, marginBottom: 4 },
  dateText: { fontSize: 22 },
  settingsBtn: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  statCard: { width: '47%' as any, borderRadius: 16, padding: 16, flexGrow: 1 },
  statIconCircle: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  statValue: { fontSize: 24, marginBottom: 4 },
  statLabel: { fontSize: 13 },
  summaryCard: { borderRadius: 16, padding: 20 },
  summaryRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 16 },
  summaryTitle: { fontSize: 16 },
  progressBarBg: { height: 10, borderRadius: 5, overflow: 'hidden', marginBottom: 10 },
  progressBarFill: { height: '100%', borderRadius: 5 },
  progressText: { fontSize: 13 },
});
