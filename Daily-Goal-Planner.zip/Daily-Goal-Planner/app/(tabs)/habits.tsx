import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, Modal, TextInput, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown, FadeIn } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';
import { useData, Habit } from '@/contexts/DataContext';

const DAY_LABELS = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];

function HabitItem({ habit, colors, onToggle, onDelete, getStreak }: { habit: Habit; colors: any; onToggle: () => void; onDelete: () => void; getStreak: (h: Habit) => number }) {
  const today = new Date().toISOString().split('T')[0];
  const dow = new Date().getDay();
  const isScheduledToday = habit.isDaily || habit.days.includes(dow);
  const isDoneToday = habit.completedDates.includes(today);
  const streak = getStreak(habit);

  return (
    <View style={[styles.habitCard, { backgroundColor: colors.card }]}>
      <View style={styles.habitHeader}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.habitTitle, { color: colors.text, fontFamily: 'Inter_600SemiBold' }]}>{habit.title}</Text>
          <Text style={[styles.habitSchedule, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>
            {habit.isDaily ? 'Каждый день' : habit.days.map(d => DAY_LABELS[d]).join(', ')}
          </Text>
        </View>
        <View style={styles.habitRight}>
          <View style={[styles.streakBadge, { backgroundColor: colors.streakBg }]}>
            <Ionicons name="flame" size={16} color={colors.streak} />
            <Text style={[styles.streakText, { color: colors.streak, fontFamily: 'Inter_700Bold' }]}>{streak}</Text>
          </View>
          <Pressable onPress={onDelete} hitSlop={8}>
            <Ionicons name="trash-outline" size={18} color={colors.textTertiary} />
          </Pressable>
        </View>
      </View>
      {isScheduledToday ? (
        <Pressable
          onPress={() => { onToggle(); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); }}
          style={({ pressed }) => [
            styles.checkBtn,
            { backgroundColor: isDoneToday ? colors.primary : colors.inputBg, opacity: pressed ? 0.85 : 1 },
          ]}
        >
          <Ionicons name={isDoneToday ? 'checkmark-circle' : 'ellipse-outline'} size={20} color={isDoneToday ? '#fff' : colors.textTertiary} />
          <Text style={[styles.checkText, { color: isDoneToday ? '#fff' : colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>
            {isDoneToday ? 'Выполнено' : 'Отметить выполненной'}
          </Text>
        </Pressable>
      ) : (
        <View style={[styles.checkBtn, { backgroundColor: colors.inputBg }]}>
          <Ionicons name="time-outline" size={18} color={colors.textTertiary} />
          <Text style={[styles.checkText, { color: colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>Не запланировано на сегодня</Text>
        </View>
      )}
    </View>
  );
}

export default function HabitsScreen() {
  const { colors } = useTheme();
  const { habits, addHabit, toggleHabitCompletion, deleteHabit, getHabitStreak } = useData();
  const insets = useSafeAreaInsets();
  const [showModal, setShowModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [isDaily, setIsDaily] = useState(true);
  const [selectedDays, setSelectedDays] = useState<number[]>([]);

  const today = new Date().toISOString().split('T')[0];

  const dailyHabits = habits.filter(h => h.isDaily);
  const scheduledHabits = habits.filter(h => !h.isDaily);

  const handleAdd = async () => {
    if (!newTitle.trim()) return;
    await addHabit({ title: newTitle.trim(), isDaily, days: isDaily ? [] : selectedDays });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setNewTitle('');
    setIsDaily(true);
    setSelectedDays([]);
    setShowModal(false);
  };

  const toggleDay = (d: number) => {
    setSelectedDays(prev => prev.includes(d) ? prev.filter(x => x !== d) : [...prev, d]);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16), paddingBottom: 100 + (Platform.OS === 'web' ? 34 : 0) }]}
        showsVerticalScrollIndicator={false}
        contentInsetAdjustmentBehavior="automatic"
      >
        <View style={styles.headerRow}>
          <Text style={[styles.screenTitle, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>Привычки</Text>
          <Pressable onPress={() => setShowModal(true)} style={({ pressed }) => [styles.addBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}>
            <Ionicons name="add" size={24} color="#fff" />
          </Pressable>
        </View>

        {habits.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="flame-outline" size={48} color={colors.textTertiary} />
            <Text style={[styles.emptyText, { color: colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Привычек пока нет</Text>
            <Text style={[styles.emptySubtext, { color: colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>Нажмите +, чтобы создать первую</Text>
          </View>
        )}

        {dailyHabits.length > 0 && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold' }]}>Ежедневные</Text>
            {dailyHabits.map((h, i) => (
              <Animated.View key={h.id} entering={FadeInDown.duration(300).delay(i * 80)}>
                <HabitItem habit={h} colors={colors} onToggle={() => toggleHabitCompletion(h.id, today)} onDelete={() => deleteHabit(h.id)} getStreak={getHabitStreak} />
              </Animated.View>
            ))}
          </>
        )}

        {scheduledHabits.length > 0 && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold', marginTop: 20 }]}>По расписанию</Text>
            {scheduledHabits.map((h, i) => (
              <Animated.View key={h.id} entering={FadeInDown.duration(300).delay(i * 80)}>
                <HabitItem habit={h} colors={colors} onToggle={() => toggleHabitCompletion(h.id, today)} onDelete={() => deleteHabit(h.id)} getStreak={getHabitStreak} />
              </Animated.View>
            ))}
          </>
        )}
      </ScrollView>

      <Modal visible={showModal} transparent animationType="slide" onRequestClose={() => setShowModal(false)}>
        <Pressable style={[styles.modalOverlay, { backgroundColor: colors.overlay }]} onPress={() => setShowModal(false)}>
          <Pressable style={[styles.modalContent, { backgroundColor: colors.card }]} onPress={() => {}}>
            <View style={styles.modalHandle} />
            <Text style={[styles.modalTitle, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>Новая привычка</Text>
            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, fontFamily: 'Inter_400Regular' }]}
              placeholder="Название привычки"
              placeholderTextColor={colors.textTertiary}
              value={newTitle}
              onChangeText={setNewTitle}
              autoFocus
            />
            <View style={styles.scheduleSection}>
              <Pressable onPress={() => setIsDaily(true)} style={[styles.scheduleOption, isDaily && { backgroundColor: colors.primaryLight, borderColor: colors.primary }]}>
                <Text style={[styles.scheduleText, { color: isDaily ? colors.primary : colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Каждый день</Text>
              </Pressable>
              <Pressable onPress={() => setIsDaily(false)} style={[styles.scheduleOption, !isDaily && { backgroundColor: colors.primaryLight, borderColor: colors.primary }]}>
                <Text style={[styles.scheduleText, { color: !isDaily ? colors.primary : colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Свои дни</Text>
              </Pressable>
            </View>
            {!isDaily && (
              <Animated.View entering={FadeIn.duration(200)} style={styles.daysRow}>
                {DAY_LABELS.map((label, i) => (
                  <Pressable
                    key={i}
                    onPress={() => toggleDay(i)}
                    style={[styles.dayChip, selectedDays.includes(i) && { backgroundColor: colors.primary }]}
                  >
                    <Text style={[styles.dayChipText, { color: selectedDays.includes(i) ? '#fff' : colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>{label}</Text>
                  </Pressable>
                ))}
              </Animated.View>
            )}
            <Pressable onPress={handleAdd} style={({ pressed }) => [styles.modalBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}>
              <Text style={[styles.modalBtnText, { fontFamily: 'Inter_600SemiBold' }]}>Добавить</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingHorizontal: 20 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 },
  screenTitle: { fontSize: 28 },
  addBtn: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  emptyState: { alignItems: 'center', paddingTop: 80, gap: 8 },
  emptyText: { fontSize: 17 },
  emptySubtext: { fontSize: 14 },
  sectionTitle: { fontSize: 13, textTransform: 'uppercase' as const, letterSpacing: 1, marginBottom: 12 },
  habitCard: { borderRadius: 16, padding: 16, marginBottom: 12 },
  habitHeader: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 12 },
  habitTitle: { fontSize: 17, marginBottom: 4 },
  habitSchedule: { fontSize: 13 },
  habitRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  streakBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  streakText: { fontSize: 14 },
  checkBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 42, borderRadius: 12 },
  checkText: { fontSize: 14 },
  modalOverlay: { flex: 1, justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40 },
  modalHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: '#ccc', alignSelf: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 22, marginBottom: 20 },
  modalInput: { height: 50, borderRadius: 14, paddingHorizontal: 16, fontSize: 16, marginBottom: 16 },
  scheduleSection: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  scheduleOption: { flex: 1, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: 'transparent' },
  scheduleText: { fontSize: 14 },
  daysRow: { flexDirection: 'row', gap: 6, marginBottom: 16, justifyContent: 'center' },
  dayChip: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center', backgroundColor: '#E5E7EB' },
  dayChipText: { fontSize: 12 },
  modalBtn: { height: 50, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  modalBtnText: { color: '#fff', fontSize: 16 },
});
