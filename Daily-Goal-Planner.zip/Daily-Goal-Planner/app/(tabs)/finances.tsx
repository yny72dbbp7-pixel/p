import React, { useState, useMemo } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, Modal, TextInput, Platform, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import Svg, { Path, Line, Text as SvgText } from 'react-native-svg';
import { useTheme } from '@/contexts/ThemeContext';
import { useData, FinanceEntry } from '@/contexts/DataContext';

const CATEGORIES_INCOME = ['Зарплата', 'Фриланс', 'Инвестиции', 'Подарок', 'Другое'];
const CATEGORIES_EXPENSE = ['Еда', 'Транспорт', 'Покупки', 'Здоровье', 'Развлечения', 'Счета', 'Другое'];

function MiniChart({ data, colors }: { data: { date: string; income: number; expense: number }[]; colors: any }) {
  const width = Dimensions.get('window').width - 72;
  const height = 160;
  const padding = { top: 10, bottom: 30, left: 10, right: 10 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  if (data.length === 0) return null;

  const maxVal = Math.max(...data.map(d => Math.max(d.income, d.expense)), 1);
  const barW = Math.min(20, (chartW / data.length - 4) / 2);

  return (
    <Svg width={width} height={height}>
      <Line x1={padding.left} y1={height - padding.bottom} x2={width - padding.right} y2={height - padding.bottom} stroke={colors.border} strokeWidth={1} />
      {data.map((d, i) => {
        const x = padding.left + (i / data.length) * chartW + chartW / data.length / 2;
        const incomeH = (d.income / maxVal) * chartH;
        const expenseH = (d.expense / maxVal) * chartH;
        return (
          <React.Fragment key={i}>
            <Path d={`M${x - barW - 1},${height - padding.bottom} L${x - barW - 1},${height - padding.bottom - incomeH} Q${x - barW - 1},${height - padding.bottom - incomeH - 3} ${x - 1},${height - padding.bottom - incomeH - 3} L${x - 1},${height - padding.bottom}`} fill={colors.income} opacity={0.8} />
            <Path d={`M${x + 1},${height - padding.bottom} L${x + 1},${height - padding.bottom - expenseH} Q${x + 1},${height - padding.bottom - expenseH - 3} ${x + barW + 1},${height - padding.bottom - expenseH - 3} L${x + barW + 1},${height - padding.bottom}`} fill={colors.expense} opacity={0.8} />
            <SvgText x={x} y={height - 6} fontSize={10} fill={colors.textTertiary} textAnchor="middle">{d.date.slice(5)}</SvgText>
          </React.Fragment>
        );
      })}
    </Svg>
  );
}

export default function FinancesScreen() {
  const { colors } = useTheme();
  const { finances, addFinance, deleteFinance } = useData();
  const insets = useSafeAreaInsets();
  const [showModal, setShowModal] = useState(false);
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [note, setNote] = useState('');

  const totalIncome = finances.filter(f => f.type === 'income').reduce((s, f) => s + f.amount, 0);
  const totalExpense = finances.filter(f => f.type === 'expense').reduce((s, f) => s + f.amount, 0);
  const balance = totalIncome - totalExpense;

  const chartData = useMemo(() => {
    const byDate: Record<string, { income: number; expense: number }> = {};
    finances.forEach(f => {
      if (!byDate[f.date]) byDate[f.date] = { income: 0, expense: 0 };
      byDate[f.date][f.type] += f.amount;
    });
    return Object.entries(byDate)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-7)
      .map(([date, vals]) => ({ date, ...vals }));
  }, [finances]);

  const sortedFinances = [...finances].sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  const handleAdd = async () => {
    const num = parseFloat(amount);
    if (!num || num <= 0 || !category) return;
    const today = new Date().toISOString().split('T')[0];
    await addFinance({ type, amount: num, category, note: note.trim(), date: today });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setAmount('');
    setCategory('');
    setNote('');
    setShowModal(false);
  };

  const categories = type === 'income' ? CATEGORIES_INCOME : CATEGORIES_EXPENSE;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16), paddingBottom: 100 + (Platform.OS === 'web' ? 34 : 0) }]}
        showsVerticalScrollIndicator={false}
        contentInsetAdjustmentBehavior="automatic"
      >
        <View style={styles.headerRow}>
          <Text style={[styles.screenTitle, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>Финансы</Text>
          <Pressable onPress={() => setShowModal(true)} style={({ pressed }) => [styles.addBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}>
            <Ionicons name="add" size={24} color="#fff" />
          </Pressable>
        </View>

        <View style={[styles.balanceCard, { backgroundColor: colors.card }]}>
          <Text style={[styles.balanceLabel, { color: colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Общий баланс</Text>
          <Text style={[styles.balanceValue, { color: balance >= 0 ? colors.income : colors.expense, fontFamily: 'Inter_700Bold' }]}>
            {balance >= 0 ? '+' : ''}{balance.toLocaleString()}
          </Text>
          <View style={styles.balanceRow}>
            <View style={styles.balanceItem}>
              <View style={[styles.balanceDot, { backgroundColor: colors.income }]} />
              <Text style={[styles.balanceItemLabel, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>Доходы</Text>
              <Text style={[styles.balanceItemValue, { color: colors.income, fontFamily: 'Inter_600SemiBold' }]}>+{totalIncome.toLocaleString()}</Text>
            </View>
            <View style={[styles.balanceDivider, { backgroundColor: colors.border }]} />
            <View style={styles.balanceItem}>
              <View style={[styles.balanceDot, { backgroundColor: colors.expense }]} />
              <Text style={[styles.balanceItemLabel, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>Расходы</Text>
              <Text style={[styles.balanceItemValue, { color: colors.expense, fontFamily: 'Inter_600SemiBold' }]}>-{totalExpense.toLocaleString()}</Text>
            </View>
          </View>
        </View>

        {chartData.length > 0 && (
          <View style={[styles.chartCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.chartTitle, { color: colors.text, fontFamily: 'Inter_600SemiBold' }]}>Аналитика</Text>
            <View style={styles.legendRow}>
              <View style={styles.legendItem}><View style={[styles.legendDot, { backgroundColor: colors.income }]} /><Text style={[styles.legendText, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>Доходы</Text></View>
              <View style={styles.legendItem}><View style={[styles.legendDot, { backgroundColor: colors.expense }]} /><Text style={[styles.legendText, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>Расходы</Text></View>
            </View>
            <MiniChart data={chartData} colors={colors} />
          </View>
        )}

        {sortedFinances.length > 0 && (
          <Text style={[styles.sectionTitle, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold' }]}>История</Text>
        )}
        {sortedFinances.map((f, i) => (
          <Animated.View key={f.id} entering={FadeInDown.duration(300).delay(i * 50)}>
            <View style={[styles.entryCard, { backgroundColor: colors.card }]}>
              <View style={[styles.entryIcon, { backgroundColor: f.type === 'income' ? colors.income + '18' : colors.expense + '18' }]}>
                <Ionicons name={f.type === 'income' ? 'trending-up' : 'trending-down'} size={20} color={f.type === 'income' ? colors.income : colors.expense} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.entryCategory, { color: colors.text, fontFamily: 'Inter_600SemiBold' }]}>{f.category}</Text>
                {!!f.note && <Text style={[styles.entryNote, { color: colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>{f.note}</Text>}
                <Text style={[styles.entryDate, { color: colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>{f.date}</Text>
              </View>
              <Text style={[styles.entryAmount, { color: f.type === 'income' ? colors.income : colors.expense, fontFamily: 'Inter_700Bold' }]}>
                {f.type === 'income' ? '+' : '-'}{f.amount.toLocaleString()}
              </Text>
              <Pressable onPress={() => deleteFinance(f.id)} hitSlop={8} style={{ marginLeft: 8 }}>
                <Ionicons name="trash-outline" size={16} color={colors.textTertiary} />
              </Pressable>
            </View>
          </Animated.View>
        ))}

        {finances.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="wallet-outline" size={48} color={colors.textTertiary} />
            <Text style={[styles.emptyText, { color: colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Записей пока нет</Text>
            <Text style={[styles.emptySubtext, { color: colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>Нажмите +, чтобы добавить доход или расход</Text>
          </View>
        )}
      </ScrollView>

      <Modal visible={showModal} transparent animationType="slide" onRequestClose={() => setShowModal(false)}>
        <Pressable style={[styles.modalOverlay, { backgroundColor: colors.overlay }]} onPress={() => setShowModal(false)}>
          <Pressable style={[styles.modalContent, { backgroundColor: colors.card }]} onPress={() => {}}>
            <View style={styles.modalHandle} />
            <Text style={[styles.modalTitle, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>Новая запись</Text>
            <View style={styles.typeRow}>
              <Pressable onPress={() => setType('income')} style={[styles.typeBtn, type === 'income' && { backgroundColor: colors.income + '20', borderColor: colors.income }]}>
                <Ionicons name="trending-up" size={18} color={type === 'income' ? colors.income : colors.textTertiary} />
                <Text style={[styles.typeText, { color: type === 'income' ? colors.income : colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Доход</Text>
              </Pressable>
              <Pressable onPress={() => setType('expense')} style={[styles.typeBtn, type === 'expense' && { backgroundColor: colors.expense + '20', borderColor: colors.expense }]}>
                <Ionicons name="trending-down" size={18} color={type === 'expense' ? colors.expense : colors.textTertiary} />
                <Text style={[styles.typeText, { color: type === 'expense' ? colors.expense : colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Расход</Text>
              </Pressable>
            </View>
            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, fontFamily: 'Inter_400Regular' }]}
              placeholder="Сумма"
              placeholderTextColor={colors.textTertiary}
              value={amount}
              onChangeText={setAmount}
              keyboardType="numeric"
              autoFocus
            />
            <Text style={[styles.catLabel, { color: colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Категория</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.catScroll} contentContainerStyle={styles.catRow}>
              {categories.map(c => (
                <Pressable key={c} onPress={() => setCategory(c)} style={[styles.catChip, category === c && { backgroundColor: colors.primaryLight, borderColor: colors.primary }]}>
                  <Text style={[styles.catChipText, { color: category === c ? colors.primary : colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>{c}</Text>
                </Pressable>
              ))}
            </ScrollView>
            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, fontFamily: 'Inter_400Regular' }]}
              placeholder="Заметка (необязательно)"
              placeholderTextColor={colors.textTertiary}
              value={note}
              onChangeText={setNote}
            />
            <Pressable onPress={handleAdd} style={({ pressed }) => [styles.modalBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}>
              <Text style={[styles.modalBtnText, { fontFamily: 'Inter_600SemiBold' }]}>Добавить</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingHorizontal: 20 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 },
  screenTitle: { fontSize: 28 },
  addBtn: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  balanceCard: { borderRadius: 20, padding: 24, marginBottom: 16 },
  balanceLabel: { fontSize: 14, marginBottom: 8 },
  balanceValue: { fontSize: 34, marginBottom: 20 },
  balanceRow: { flexDirection: 'row', alignItems: 'center' },
  balanceItem: { flex: 1, alignItems: 'center', gap: 4 },
  balanceDot: { width: 8, height: 8, borderRadius: 4 },
  balanceItemLabel: { fontSize: 12 },
  balanceItemValue: { fontSize: 16 },
  balanceDivider: { width: 1, height: 40 },
  chartCard: { borderRadius: 20, padding: 20, marginBottom: 20 },
  chartTitle: { fontSize: 17, marginBottom: 8 },
  legendRow: { flexDirection: 'row', gap: 16, marginBottom: 12 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { fontSize: 12 },
  sectionTitle: { fontSize: 13, textTransform: 'uppercase' as const, letterSpacing: 1, marginBottom: 12 },
  entryCard: { flexDirection: 'row', alignItems: 'center', gap: 12, borderRadius: 14, padding: 14, marginBottom: 8 },
  entryIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  entryCategory: { fontSize: 15 },
  entryNote: { fontSize: 12, marginTop: 2 },
  entryDate: { fontSize: 11, marginTop: 2 },
  entryAmount: { fontSize: 16 },
  emptyState: { alignItems: 'center', paddingTop: 60, gap: 8 },
  emptyText: { fontSize: 17 },
  emptySubtext: { fontSize: 14 },
  modalOverlay: { flex: 1, justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40, maxHeight: '85%' },
  modalHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: '#ccc', alignSelf: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 22, marginBottom: 16 },
  typeRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  typeBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, height: 46, borderRadius: 12, borderWidth: 1.5, borderColor: 'transparent' },
  typeText: { fontSize: 14 },
  modalInput: { height: 50, borderRadius: 14, paddingHorizontal: 16, fontSize: 16, marginBottom: 12 },
  catLabel: { fontSize: 13, marginBottom: 8 },
  catScroll: { marginBottom: 12 },
  catRow: { gap: 8 },
  catChip: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, borderWidth: 1.5, borderColor: 'transparent', backgroundColor: '#E5E7EB' },
  catChipText: { fontSize: 13 },
  modalBtn: { height: 50, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  modalBtnText: { color: '#fff', fontSize: 16 },
});
