import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, TextInput, Platform, Alert, ActionSheetIOS } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as Sharing from 'expo-sharing';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';
import { useData, DayPlanItem, Attachment } from '@/contexts/DataContext';

const WEEKDAYS_RU = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
const MONTHS_RU = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function getAttachmentIcon(type: string) {
  switch (type) {
    case 'image': return 'image-outline';
    case 'video': return 'videocam-outline';
    default: return 'document-outline';
  }
}

function AttachmentItem({ attachment, colors, onRemove, onShare }: { attachment: Attachment; colors: any; onRemove: () => void; onShare: () => void }) {
  const isImage = attachment.type === 'image';

  return (
    <View style={[styles.attachItem, { backgroundColor: colors.inputBg }]}>
      {isImage ? (
        <Image source={{ uri: attachment.uri }} style={styles.attachThumb} contentFit="cover" />
      ) : (
        <View style={[styles.attachIconWrap, { backgroundColor: colors.primaryLight }]}>
          <Ionicons name={getAttachmentIcon(attachment.type) as any} size={18} color={colors.primary} />
        </View>
      )}
      <Text style={[styles.attachName, { color: colors.text, fontFamily: 'Inter_400Regular' }]} numberOfLines={1}>{attachment.name}</Text>
      <Pressable onPress={onShare} hitSlop={6} style={styles.attachAction}>
        <Ionicons name="download-outline" size={18} color={colors.primary} />
      </Pressable>
      <Pressable onPress={onRemove} hitSlop={6} style={styles.attachAction}>
        <Ionicons name="close-circle-outline" size={18} color={colors.textTertiary} />
      </Pressable>
    </View>
  );
}

function PlanItemCard({ item, colors, onToggle, onDelete, onAddAttach, onRemoveAttach, onShareOne, onShareAll }: {
  item: DayPlanItem; colors: any;
  onToggle: () => void; onDelete: () => void;
  onAddAttach: () => void;
  onRemoveAttach: (attId: string) => void;
  onShareOne: (att: Attachment) => void;
  onShareAll: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const attachments = item.attachments || [];
  const hasAttachments = attachments.length > 0;

  return (
    <View style={[styles.planCard, { backgroundColor: colors.card }]}>
      <View style={styles.planRow}>
        <Pressable onPress={() => { onToggle(); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }} hitSlop={8}>
          <Ionicons name={item.completed ? 'checkmark-circle' : 'ellipse-outline'} size={24} color={item.completed ? colors.primary : colors.textTertiary} />
        </Pressable>
        <Pressable onPress={() => setExpanded(!expanded)} style={{ flex: 1 }}>
          <Text style={[styles.planText, { color: colors.text, fontFamily: 'Inter_500Medium', textDecorationLine: item.completed ? 'line-through' : 'none', opacity: item.completed ? 0.5 : 1 }]}>
            {item.title}
          </Text>
          {hasAttachments && !expanded && (
            <View style={styles.attachBadgeRow}>
              <Ionicons name="attach" size={14} color={colors.textTertiary} />
              <Text style={[styles.attachBadgeText, { color: colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>
                {attachments.length} {attachments.length === 1 ? 'файл' : attachments.length < 5 ? 'файла' : 'файлов'}
              </Text>
            </View>
          )}
        </Pressable>
        <Pressable onPress={onAddAttach} hitSlop={8} style={{ marginRight: 6 }}>
          <Ionicons name="attach" size={20} color={colors.primary} />
        </Pressable>
        <Pressable onPress={onDelete} hitSlop={8}>
          <Ionicons name="close" size={18} color={colors.textTertiary} />
        </Pressable>
      </View>

      {expanded && hasAttachments && (
        <View style={[styles.attachSection, { borderTopColor: colors.border }]}>
          {attachments.map(att => (
            <AttachmentItem
              key={att.id}
              attachment={att}
              colors={colors}
              onRemove={() => onRemoveAttach(att.id)}
              onShare={() => onShareOne(att)}
            />
          ))}
          {attachments.length > 1 && (
            <Pressable onPress={onShareAll} style={({ pressed }) => [styles.downloadAllBtn, { backgroundColor: colors.primaryLight, opacity: pressed ? 0.8 : 1 }]}>
              <Ionicons name="download-outline" size={18} color={colors.primary} />
              <Text style={[styles.downloadAllText, { color: colors.primary, fontFamily: 'Inter_600SemiBold' }]}>Скачать все</Text>
            </Pressable>
          )}
        </View>
      )}

      {expanded && !hasAttachments && (
        <View style={[styles.attachSection, { borderTopColor: colors.border }]}>
          <Pressable onPress={onAddAttach} style={({ pressed }) => [styles.addAttachBtn, { backgroundColor: colors.inputBg, opacity: pressed ? 0.8 : 1 }]}>
            <Ionicons name="add-circle-outline" size={20} color={colors.textTertiary} />
            <Text style={[styles.addAttachText, { color: colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>Добавить файлы</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

export default function DayPlanScreen() {
  const { colors } = useTheme();
  const { dayPlanItems, addDayPlanItem, toggleDayPlanItem, deleteDayPlanItem, addAttachment, removeAttachment, getDayNote, updateDayNote } = useData();
  const insets = useSafeAreaInsets();
  const today = new Date().toISOString().split('T')[0];
  const todayItems = dayPlanItems.filter(i => i.date === today);
  const currentNote = getDayNote(today);
  const [newItem, setNewItem] = useState('');
  const [noteText, setNoteText] = useState(currentNote?.content || '');
  const [noteEditing, setNoteEditing] = useState(false);

  const now = new Date();
  const dateStr = `${WEEKDAYS_RU[now.getDay()]}, ${now.getDate()} ${MONTHS_RU[now.getMonth()]}`;

  const handleAddItem = async () => {
    if (!newItem.trim()) return;
    await addDayPlanItem(newItem.trim(), today);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setNewItem('');
  };

  const handleSaveNote = async () => {
    await updateDayNote(today, noteText);
    setNoteEditing(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleAddAttachment = async (itemId: string) => {
    const options = ['Фото/Видео из галереи', 'Сделать фото', 'Выбрать файл', 'Отмена'];
    const cancelIndex = 3;

    const showPicker = (index: number) => {
      switch (index) {
        case 0: pickMedia(itemId); break;
        case 1: takePhoto(itemId); break;
        case 2: pickDocument(itemId); break;
      }
    };

    if (Platform.OS === 'ios') {
      ActionSheetIOS.showActionSheetWithOptions(
        { options, cancelButtonIndex: cancelIndex },
        showPicker,
      );
    } else {
      Alert.alert('Добавить вложение', '', [
        { text: 'Фото/Видео из галереи', onPress: () => pickMedia(itemId) },
        { text: 'Сделать фото', onPress: () => takePhoto(itemId) },
        { text: 'Выбрать файл', onPress: () => pickDocument(itemId) },
        { text: 'Отмена', style: 'cancel' },
      ]);
    }
  };

  const pickMedia = async (itemId: string) => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images', 'videos'],
      allowsMultipleSelection: true,
      quality: 0.8,
    });
    if (!result.canceled) {
      for (const asset of result.assets) {
        const name = asset.fileName || asset.uri.split('/').pop() || 'media';
        const type = asset.type === 'video' ? 'video' : 'image';
        await addAttachment(itemId, { name, uri: asset.uri, type, mimeType: asset.mimeType });
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const takePhoto = async (itemId: string) => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Нет доступа', 'Разрешите доступ к камере в настройках');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.8 });
    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];
      const name = asset.fileName || 'photo.jpg';
      await addAttachment(itemId, { name, uri: asset.uri, type: 'image', mimeType: asset.mimeType });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const pickDocument = async (itemId: string) => {
    const result = await DocumentPicker.getDocumentAsync({ multiple: true, copyToCacheDirectory: true });
    if (!result.canceled) {
      for (const asset of result.assets) {
        await addAttachment(itemId, { name: asset.name, uri: asset.uri, type: 'file', mimeType: asset.mimeType });
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleShareOne = async (att: Attachment) => {
    try {
      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(att.uri);
      } else {
        Alert.alert('Ошибка', 'Функция "Поделиться" недоступна на этом устройстве');
      }
    } catch {
      Alert.alert('Ошибка', 'Не удалось поделиться файлом');
    }
  };

  const handleShareAll = async (item: DayPlanItem) => {
    const attachments = item.attachments || [];
    if (attachments.length === 0) return;
    try {
      const canShare = await Sharing.isAvailableAsync();
      if (!canShare) {
        Alert.alert('Ошибка', 'Функция "Поделиться" недоступна на этом устройстве');
        return;
      }
      for (const att of attachments) {
        await Sharing.shareAsync(att.uri);
      }
    } catch {
      Alert.alert('Ошибка', 'Не удалось поделиться файлами');
    }
  };

  const doneCount = todayItems.filter(i => i.completed).length;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16), paddingBottom: 100 + (Platform.OS === 'web' ? 34 : 0) }]}
        showsVerticalScrollIndicator={false}
        contentInsetAdjustmentBehavior="automatic"
      >
        <Text style={[styles.screenTitle, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>План дня</Text>
        <Text style={[styles.dateSubtitle, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>
          {dateStr}
          {todayItems.length > 0 ? ` \u2022 ${doneCount}/${todayItems.length}` : ''}
        </Text>

        <View style={[styles.inputRow, { backgroundColor: colors.card }]}>
          <TextInput
            style={[styles.addInput, { color: colors.text, fontFamily: 'Inter_400Regular' }]}
            placeholder="Добавить задачу на сегодня"
            placeholderTextColor={colors.textTertiary}
            value={newItem}
            onChangeText={setNewItem}
            returnKeyType="done"
            onSubmitEditing={handleAddItem}
          />
          <Pressable onPress={handleAddItem} style={({ pressed }) => [styles.inputBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}>
            <Ionicons name="add" size={22} color="#fff" />
          </Pressable>
        </View>

        {todayItems.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="calendar-outline" size={48} color={colors.textTertiary} />
            <Text style={[styles.emptyText, { color: colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Планов на сегодня нет</Text>
          </View>
        )}

        {todayItems.map((item, i) => (
          <Animated.View key={item.id} entering={FadeInDown.duration(300).delay(i * 60)}>
            <PlanItemCard
              item={item}
              colors={colors}
              onToggle={() => toggleDayPlanItem(item.id)}
              onDelete={() => deleteDayPlanItem(item.id)}
              onAddAttach={() => handleAddAttachment(item.id)}
              onRemoveAttach={(attId) => removeAttachment(item.id, attId)}
              onShareOne={handleShareOne}
              onShareAll={() => handleShareAll(item)}
            />
          </Animated.View>
        ))}

        <View style={{ marginTop: 28 }}>
          <View style={styles.notesHeader}>
            <View style={styles.notesHeaderLeft}>
              <Ionicons name="document-text-outline" size={20} color={colors.primary} />
              <Text style={[styles.notesTitle, { color: colors.text, fontFamily: 'Inter_600SemiBold' }]}>Заметки дня</Text>
            </View>
            {noteEditing ? (
              <Pressable onPress={handleSaveNote} hitSlop={8}>
                <Ionicons name="checkmark" size={22} color={colors.primary} />
              </Pressable>
            ) : (
              <Pressable onPress={() => setNoteEditing(true)} hitSlop={8}>
                <Ionicons name="create-outline" size={20} color={colors.textTertiary} />
              </Pressable>
            )}
          </View>
          <View style={[styles.notesCard, { backgroundColor: colors.card }]}>
            {noteEditing ? (
              <TextInput
                style={[styles.noteInput, { color: colors.text, fontFamily: 'Inter_400Regular' }]}
                placeholder="Запишите мысли на сегодня..."
                placeholderTextColor={colors.textTertiary}
                value={noteText}
                onChangeText={setNoteText}
                multiline
                textAlignVertical="top"
                autoFocus
              />
            ) : (
              <Pressable onPress={() => setNoteEditing(true)}>
                <Text style={[styles.noteDisplay, { color: noteText ? colors.text : colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>
                  {noteText || 'Нажмите, чтобы добавить заметки...'}
                </Text>
              </Pressable>
            )}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingHorizontal: 20 },
  screenTitle: { fontSize: 28, marginBottom: 4 },
  dateSubtitle: { fontSize: 14, marginBottom: 24 },
  inputRow: { flexDirection: 'row', alignItems: 'center', borderRadius: 14, paddingLeft: 16, paddingRight: 6, paddingVertical: 6, marginBottom: 20, gap: 8 },
  addInput: { flex: 1, height: 40, fontSize: 15 },
  inputBtn: { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  emptyState: { alignItems: 'center', paddingTop: 40, gap: 8, marginBottom: 20 },
  emptyText: { fontSize: 16 },
  planCard: { borderRadius: 16, padding: 14, marginBottom: 10 },
  planRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  planText: { fontSize: 15 },
  attachBadgeRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  attachBadgeText: { fontSize: 12 },
  attachSection: { borderTopWidth: 1, marginTop: 12, paddingTop: 12, gap: 8 },
  attachItem: { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 10, padding: 8 },
  attachThumb: { width: 36, height: 36, borderRadius: 6 },
  attachIconWrap: { width: 36, height: 36, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  attachName: { flex: 1, fontSize: 13 },
  attachAction: { padding: 4 },
  downloadAllBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 40, borderRadius: 10 },
  downloadAllText: { fontSize: 14 },
  addAttachBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 40, borderRadius: 10 },
  addAttachText: { fontSize: 13 },
  notesHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  notesHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  notesTitle: { fontSize: 17 },
  notesCard: { borderRadius: 16, padding: 16, minHeight: 120 },
  noteInput: { fontSize: 15, lineHeight: 22, minHeight: 100 },
  noteDisplay: { fontSize: 15, lineHeight: 22 },
});
