import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, Modal, TextInput, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';
import { useData, Task } from '@/contexts/DataContext';

const MONTHS_RU_SHORT = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];

function formatDateRu(dateStr: string) {
  const d = new Date(dateStr);
  return `${d.getDate()} ${MONTHS_RU_SHORT[d.getMonth()]} ${d.getFullYear()}`;
}

function TaskItem({ task, colors, onToggle, onDelete }: { task: Task; colors: any; onToggle: () => void; onDelete: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const deadlineDate = new Date(task.deadline);
  const isOverdue = !task.completed && deadlineDate < new Date();

  return (
    <Pressable onPress={() => setExpanded(!expanded)} style={[styles.taskCard, { backgroundColor: colors.card }]}>
      <View style={styles.taskRow}>
        <Pressable onPress={() => { onToggle(); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }} hitSlop={8}>
          <Ionicons name={task.completed ? 'checkmark-circle' : 'ellipse-outline'} size={24} color={task.completed ? colors.primary : colors.textTertiary} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={[styles.taskTitle, { color: colors.text, fontFamily: 'Inter_600SemiBold', textDecorationLine: task.completed ? 'line-through' : 'none', opacity: task.completed ? 0.5 : 1 }]}>{task.title}</Text>
          <View style={styles.deadlineRow}>
            <Ionicons name="time-outline" size={14} color={isOverdue ? colors.expense : colors.textTertiary} />
            <Text style={[styles.deadlineText, { color: isOverdue ? colors.expense : colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>{formatDateRu(task.deadline)}</Text>
          </View>
        </View>
        <Pressable onPress={onDelete} hitSlop={8}>
          <Ionicons name="trash-outline" size={18} color={colors.textTertiary} />
        </Pressable>
      </View>
      {expanded && !!task.note && (
        <View style={[styles.noteSection, { borderTopColor: colors.border }]}>
          <Text style={[styles.noteText, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>{task.note}</Text>
        </View>
      )}
    </Pressable>
  );
}

export default function TasksScreen() {
  const { colors } = useTheme();
  const { tasks, addTask, toggleTask, deleteTask } = useData();
  const insets = useSafeAreaInsets();
  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [note, setNote] = useState('');
  const [deadline, setDeadline] = useState('');

  const activeTasks = tasks.filter(t => !t.completed);
  const completedTasks = tasks.filter(t => t.completed);

  const handleAdd = async () => {
    if (!title.trim()) return;
    const dl = deadline.trim() || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    await addTask({ title: title.trim(), note: note.trim(), deadline: dl });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setTitle('');
    setNote('');
    setDeadline('');
    setShowModal(false);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16), paddingBottom: 100 + (Platform.OS === 'web' ? 34 : 0) }]}
        showsVerticalScrollIndicator={false}
        contentInsetAdjustmentBehavior="automatic"
      >
        <View style={styles.headerRow}>
          <Text style={[styles.screenTitle, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>Задачи</Text>
          <Pressable onPress={() => setShowModal(true)} style={({ pressed }) => [styles.addBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}>
            <Ionicons name="add" size={24} color="#fff" />
          </Pressable>
        </View>

        {tasks.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="checkmark-done-outline" size={48} color={colors.textTertiary} />
            <Text style={[styles.emptyText, { color: colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>Задач пока нет</Text>
            <Text style={[styles.emptySubtext, { color: colors.textTertiary, fontFamily: 'Inter_400Regular' }]}>Нажмите +, чтобы добавить задачу</Text>
          </View>
        )}

        {activeTasks.length > 0 && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold' }]}>Активные ({activeTasks.length})</Text>
            {activeTasks.map((t, i) => (
              <Animated.View key={t.id} entering={FadeInDown.duration(300).delay(i * 60)}>
                <TaskItem task={t} colors={colors} onToggle={() => toggleTask(t.id)} onDelete={() => deleteTask(t.id)} />
              </Animated.View>
            ))}
          </>
        )}

        {completedTasks.length > 0 && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold', marginTop: 20 }]}>Выполненные ({completedTasks.length})</Text>
            {completedTasks.map((t, i) => (
              <Animated.View key={t.id} entering={FadeInDown.duration(300).delay(i * 60)}>
                <TaskItem task={t} colors={colors} onToggle={() => toggleTask(t.id)} onDelete={() => deleteTask(t.id)} />
              </Animated.View>
            ))}
          </>
        )}
      </ScrollView>

      <Modal visible={showModal} transparent animationType="slide" onRequestClose={() => setShowModal(false)}>
        <Pressable style={[styles.modalOverlay, { backgroundColor: colors.overlay }]} onPress={() => setShowModal(false)}>
          <Pressable style={[styles.modalContent, { backgroundColor: colors.card }]} onPress={() => {}}>
            <View style={styles.modalHandle} />
            <Text style={[styles.modalTitle, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>Новая задача</Text>
            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, fontFamily: 'Inter_400Regular' }]}
              placeholder="Название задачи"
              placeholderTextColor={colors.textTertiary}
              value={title}
              onChangeText={setTitle}
              autoFocus
            />
            <TextInput
              style={[styles.modalInput, styles.noteInput, { backgroundColor: colors.inputBg, color: colors.text, fontFamily: 'Inter_400Regular' }]}
              placeholder="Заметка (необязательно)"
              placeholderTextColor={colors.textTertiary}
              value={note}
              onChangeText={setNote}
              multiline
              textAlignVertical="top"
            />
            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, fontFamily: 'Inter_400Regular' }]}
              placeholder="Дедлайн (ГГГГ-ММ-ДД)"
              placeholderTextColor={colors.textTertiary}
              value={deadline}
              onChangeText={setDeadline}
            />
            <Pressable onPress={handleAdd} style={({ pressed }) => [styles.modalBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}>
              <Text style={[styles.modalBtnText, { fontFamily: 'Inter_600SemiBold' }]}>Добавить</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingHorizontal: 20 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 },
  screenTitle: { fontSize: 28 },
  addBtn: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  emptyState: { alignItems: 'center', paddingTop: 80, gap: 8 },
  emptyText: { fontSize: 17 },
  emptySubtext: { fontSize: 14 },
  sectionTitle: { fontSize: 13, textTransform: 'uppercase' as const, letterSpacing: 1, marginBottom: 12 },
  taskCard: { borderRadius: 16, padding: 16, marginBottom: 10 },
  taskRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  taskTitle: { fontSize: 16, marginBottom: 4 },
  deadlineRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  deadlineText: { fontSize: 12 },
  noteSection: { borderTopWidth: 1, marginTop: 12, paddingTop: 12 },
  noteText: { fontSize: 14, lineHeight: 20 },
  modalOverlay: { flex: 1, justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40 },
  modalHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: '#ccc', alignSelf: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 22, marginBottom: 20 },
  modalInput: { height: 50, borderRadius: 14, paddingHorizontal: 16, fontSize: 16, marginBottom: 12 },
  noteInput: { height: 90, paddingTop: 14 },
  modalBtn: { height: 50, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  modalBtnText: { color: '#fff', fontSize: 16 },
});
