import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Pressable, TextInput, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';
import { useUser } from '@/contexts/UserContext';
import { router } from 'expo-router';

export default function SettingsScreen() {
  const { colors, themeMode, setThemeMode } = useTheme();
  const { user, updateName, updateAvatar } = useUser();
  const insets = useSafeAreaInsets();
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(user?.name || '');

  const handlePickAvatar = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      await updateAvatar(result.assets[0].uri);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleSaveName = async () => {
    if (nameInput.trim()) {
      await updateName(nameInput.trim());
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setEditingName(false);
  };

  const themes: { key: 'light' | 'dark' | 'system'; label: string; icon: string }[] = [
    { key: 'light', label: 'Светлая', icon: 'sunny' },
    { key: 'dark', label: 'Тёмная', icon: 'moon' },
    { key: 'system', label: 'Системная', icon: 'phone-portrait' },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 16), paddingBottom: 100 + (Platform.OS === 'web' ? 34 : 0) }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerRow}>
          <Pressable onPress={() => router.back()} hitSlop={8}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </Pressable>
          <Text style={[styles.screenTitle, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>Настройки</Text>
          <View style={{ width: 24 }} />
        </View>

        <View style={[styles.profileCard, { backgroundColor: colors.card }]}>
          <Pressable onPress={handlePickAvatar} style={styles.avatarWrap}>
            {user?.avatar ? (
              <Image source={{ uri: user.avatar }} style={styles.avatar} contentFit="cover" />
            ) : (
              <View style={[styles.avatarPlaceholder, { backgroundColor: colors.primaryLight }]}>
                <Ionicons name="person" size={36} color={colors.primary} />
              </View>
            )}
            <View style={[styles.editBadge, { backgroundColor: colors.primary }]}>
              <Ionicons name="camera" size={14} color="#fff" />
            </View>
          </Pressable>
          {editingName ? (
            <View style={styles.nameEditRow}>
              <TextInput
                style={[styles.nameInput, { backgroundColor: colors.inputBg, color: colors.text, fontFamily: 'Inter_400Regular' }]}
                value={nameInput}
                onChangeText={setNameInput}
                autoFocus
                returnKeyType="done"
                onSubmitEditing={handleSaveName}
              />
              <Pressable onPress={handleSaveName} hitSlop={8}>
                <Ionicons name="checkmark" size={24} color={colors.primary} />
              </Pressable>
            </View>
          ) : (
            <Pressable onPress={() => { setNameInput(user?.name || ''); setEditingName(true); }} style={styles.nameRow}>
              <Text style={[styles.userName, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>{user?.name}</Text>
              <Ionicons name="create-outline" size={18} color={colors.textTertiary} />
            </Pressable>
          )}
        </View>

        <Text style={[styles.sectionTitle, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold' }]}>Оформление</Text>
        <View style={[styles.themeCard, { backgroundColor: colors.card }]}>
          {themes.map(t => (
            <Pressable
              key={t.key}
              onPress={() => { setThemeMode(t.key); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
              style={[styles.themeOption, themeMode === t.key && { backgroundColor: colors.primaryLight }]}
            >
              <Ionicons name={t.icon as any} size={22} color={themeMode === t.key ? colors.primary : colors.textSecondary} />
              <Text style={[styles.themeLabel, { color: themeMode === t.key ? colors.primary : colors.textSecondary, fontFamily: 'Inter_500Medium' }]}>{t.label}</Text>
              {themeMode === t.key && <Ionicons name="checkmark-circle" size={20} color={colors.primary} style={{ marginLeft: 'auto' }} />}
            </Pressable>
          ))}
        </View>

        <Text style={[styles.sectionTitle, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold', marginTop: 24 }]}>О приложении</Text>
        <View style={[styles.aboutCard, { backgroundColor: colors.card }]}>
          <View style={styles.aboutRow}>
            <Text style={[styles.aboutLabel, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>Приложение</Text>
            <Text style={[styles.aboutValue, { color: colors.text, fontFamily: 'Inter_500Medium' }]}>JUST Go</Text>
          </View>
          <View style={[styles.aboutDivider, { backgroundColor: colors.border }]} />
          <View style={styles.aboutRow}>
            <Text style={[styles.aboutLabel, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>Версия</Text>
            <Text style={[styles.aboutValue, { color: colors.text, fontFamily: 'Inter_500Medium' }]}>1.0.0</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingHorizontal: 20 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 },
  screenTitle: { fontSize: 22 },
  profileCard: { borderRadius: 20, padding: 24, alignItems: 'center', marginBottom: 28 },
  avatarWrap: { position: 'relative', marginBottom: 16 },
  avatar: { width: 90, height: 90, borderRadius: 45 },
  avatarPlaceholder: { width: 90, height: 90, borderRadius: 45, alignItems: 'center', justifyContent: 'center' },
  editBadge: { position: 'absolute', bottom: 0, right: 0, width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  userName: { fontSize: 22 },
  nameEditRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  nameInput: { flex: 1, height: 44, borderRadius: 12, paddingHorizontal: 14, fontSize: 16 },
  sectionTitle: { fontSize: 13, textTransform: 'uppercase' as const, letterSpacing: 1, marginBottom: 10 },
  themeCard: { borderRadius: 16, overflow: 'hidden' },
  themeOption: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16 },
  themeLabel: { fontSize: 16 },
  aboutCard: { borderRadius: 16, padding: 16 },
  aboutRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 },
  aboutLabel: { fontSize: 14 },
  aboutValue: { fontSize: 14 },
  aboutDivider: { height: 1, marginVertical: 4 },
});
