import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Platform, KeyboardAvoidingView } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useUser } from '@/contexts/UserContext';
import { useTheme } from '@/contexts/ThemeContext';

export default function RegisterScreen() {
  const { user, isLoading, register } = useUser();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isLoading && user) {
      router.replace('/(tabs)');
    }
  }, [isLoading, user]);

  if (isLoading || user) return null;

  const handleRegister = async () => {
    const trimmed = name.trim();
    if (!trimmed) {
      setError('Пожалуйста, введите ваше имя');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    await register(trimmed);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.replace('/(tabs)');
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={[styles.inner, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 0), paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 0) }]}>
        <Animated.View entering={FadeInUp.duration(600)} style={styles.headerSection}>
          <View style={[styles.iconCircle, { backgroundColor: colors.primary }]}>
            <Ionicons name="rocket" size={40} color="#fff" />
          </View>
          <Text style={[styles.title, { color: colors.text, fontFamily: 'Inter_700Bold' }]}>JUST Go</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary, fontFamily: 'Inter_400Regular' }]}>
            Ваш помощник продуктивности
          </Text>
        </Animated.View>

        <Animated.View entering={FadeInDown.duration(600).delay(200)} style={styles.formSection}>
          <Text style={[styles.label, { color: colors.text, fontFamily: 'Inter_600SemiBold' }]}>Как вас зовут?</Text>
          <TextInput
            style={[styles.input, { backgroundColor: colors.inputBg, color: colors.text, borderColor: error ? colors.expense : colors.border, fontFamily: 'Inter_400Regular' }]}
            placeholder="Введите ваше имя"
            placeholderTextColor={colors.textTertiary}
            value={name}
            onChangeText={(t) => { setName(t); setError(''); }}
            autoFocus
            returnKeyType="done"
            onSubmitEditing={handleRegister}
          />
          {!!error && <Text style={[styles.error, { color: colors.expense, fontFamily: 'Inter_400Regular' }]}>{error}</Text>}

          <Pressable
            onPress={handleRegister}
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.97 : 1 }] },
            ]}
          >
            <Text style={[styles.buttonText, { fontFamily: 'Inter_600SemiBold' }]}>Начать</Text>
            <Ionicons name="arrow-forward" size={20} color="#fff" />
          </Pressable>
        </Animated.View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  inner: { flex: 1, justifyContent: 'center', paddingHorizontal: 28 },
  headerSection: { alignItems: 'center', marginBottom: 48 },
  iconCircle: { width: 80, height: 80, borderRadius: 24, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title: { fontSize: 36, marginBottom: 8 },
  subtitle: { fontSize: 16 },
  formSection: { gap: 12 },
  label: { fontSize: 16, marginBottom: 4 },
  input: { height: 52, borderRadius: 14, paddingHorizontal: 16, fontSize: 16, borderWidth: 1.5 },
  error: { fontSize: 13 },
  button: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', height: 52, borderRadius: 14, gap: 8, marginTop: 8 },
  buttonText: { color: '#fff', fontSize: 17 },
});
